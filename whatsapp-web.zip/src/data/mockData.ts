import { Contact, Chat, Message, UserStatus, Community, CallRecord, DailyUsage } from '../types';

export const initialContacts: Contact[] = [
  {
    id: 'c1',
    name: 'Aarav Sharma',
    phone: '+91 98765 43210',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    about: 'Hey there! I am using WhatsApp.',
    isOnline: true,
  },
  {
    id: 'c2',
    name: 'Priya Patel',
    phone: '+91 98111 22334',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    about: 'At work 💼 | Urgent calls only',
    isOnline: false,
    lastSeen: 'Today at 11:45 AM',
  },
  {
    id: 'c3',
    name: 'Rohan Verma',
    phone: '+91 99887 76655',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    about: 'Coding & Coffee ☕💻',
    isOnline: true,
  },
  {
    id: 'c4',
    name: 'Ananya Gupta',
    phone: '+91 97654 32109',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    about: 'Living life one day at a time ✨',
    isOnline: false,
    lastSeen: 'Yesterday at 9:15 PM',
  },
  {
    id: 'c5',
    name: 'Vikram Singh',
    phone: '+91 98223 34455',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    about: 'Available',
    isOnline: true,
  },
  {
    id: 'c6',
    name: 'Neha Roy',
    phone: '+91 98989 12345',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    about: 'Design is intelligence made visible 🎨',
    isOnline: false,
    lastSeen: 'Today at 10:12 AM',
  }
];

export const initialChats: Chat[] = [
  {
    id: 'chat_c1',
    type: 'direct',
    name: 'Aarav Sharma',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    contactId: 'c1',
    lastMessage: 'Check the project contract PDF and live location below!',
    lastMessageTime: '12:30 PM',
    unreadCount: 1,
    isPinned: true,
  },
  {
    id: 'chat_group1',
    type: 'group',
    name: 'Weekend Trip to Manali 🏔️',
    avatar: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=150&auto=format&fit=crop&q=80',
    participants: ['c1', 'c2', 'c3', 'c4'],
    lastMessage: 'Rohan: Let us do a group video call tonight at 8 PM!',
    lastMessageTime: '11:15 AM',
    unreadCount: 3,
    groupDescription: 'Planning route, hotel bookings, and vehicle pooling for Manali trip! 🚗🏕️',
    isPinned: true,
  },
  {
    id: 'chat_c2',
    type: 'direct',
    name: 'Priya Patel',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    contactId: 'c2',
    lastMessage: 'Got it, see you at the meeting!',
    lastMessageTime: 'Yesterday',
    unreadCount: 0,
  },
  {
    id: 'chat_comm_announcements',
    type: 'community_channel',
    name: 'Tech Innovators Hub (Announcements)',
    avatar: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=150&auto=format&fit=crop&q=80',
    communityId: 'comm_tech',
    lastMessage: 'Admin: New hackathon registration is open for next week! 🚀',
    lastMessageTime: 'Yesterday',
    unreadCount: 0,
  },
  {
    id: 'chat_c3',
    type: 'direct',
    name: 'Rohan Verma',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    contactId: 'c3',
    lastMessage: 'Are you free for a quick voice call?',
    lastMessageTime: 'Sep 7',
    unreadCount: 0,
  },
  {
    id: 'chat_c4',
    type: 'direct',
    name: 'Ananya Gupta',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    contactId: 'c4',
    lastMessage: 'Thank you so much! 😊',
    lastMessageTime: 'Sep 6',
    unreadCount: 0,
    isArchived: false,
  }
];

export const initialMessages: Record<string, Message[]> = {
  'chat_c1': [
    {
      id: 'm1',
      chatId: 'chat_c1',
      senderId: 'c1',
      senderName: 'Aarav Sharma',
      text: 'Hey! Hope you are doing great.',
      timestamp: '11:45 AM',
      date: '2026-09-09',
      status: 'read',
      type: 'text',
    },
    {
      id: 'm2',
      chatId: 'chat_c1',
      senderId: 'me',
      text: 'Hi Aarav! Yes all good. Did you review the client brief?',
      timestamp: '11:48 AM',
      date: '2026-09-09',
      status: 'read',
      type: 'text',
    },
    {
      id: 'm3',
      chatId: 'chat_c1',
      senderId: 'c1',
      senderName: 'Aarav Sharma',
      text: 'Yes, here is the approved proposal document for your review.',
      timestamp: '12:05 PM',
      date: '2026-09-09',
      status: 'read',
      type: 'document',
      attachment: {
        fileName: 'Project_Contract_NDA_2026.pdf',
        fileSize: '2.4 MB',
        fileType: 'pdf',
        url: '#',
      },
      reactions: { '👍': 1, '❤️': 1 },
    },
    {
      id: 'm4',
      chatId: 'chat_c1',
      senderId: 'me',
      text: 'Awesome, looks comprehensive. Where are we meeting for lunch?',
      timestamp: '12:15 PM',
      date: '2026-09-09',
      status: 'read',
      type: 'text',
    },
    {
      id: 'm5',
      chatId: 'chat_c1',
      senderId: 'c1',
      senderName: 'Aarav Sharma',
      text: 'Sharing my current cafe location right here! See you in 20 mins.',
      timestamp: '12:20 PM',
      date: '2026-09-09',
      status: 'read',
      type: 'location',
      attachment: {
        locationName: 'Cafe Mocha & Co., Connaught Place',
        latitude: 28.6315,
        longitude: 77.2167,
      },
    },
    {
      id: 'm6',
      chatId: 'chat_c1',
      senderId: 'c1',
      senderName: 'Aarav Sharma',
      text: 'Check the project contract PDF and live location below!',
      timestamp: '12:30 PM',
      date: '2026-09-09',
      status: 'delivered',
      type: 'text',
    }
  ],
  'chat_group1': [
    {
      id: 'gm1',
      chatId: 'chat_group1',
      senderId: 'c1',
      senderName: 'Aarav Sharma',
      text: 'Guys, weather forecast looks clear in Manali this coming weekend! ☀️',
      timestamp: '10:30 AM',
      date: '2026-09-09',
      status: 'read',
      type: 'text',
    },
    {
      id: 'gm2',
      chatId: 'chat_group1',
      senderId: 'c2',
      senderName: 'Priya Patel',
      text: 'Should we hire an SUV or drive two cars?',
      timestamp: '10:45 AM',
      date: '2026-09-09',
      status: 'read',
      type: 'text',
    },
    {
      id: 'gm3',
      chatId: 'chat_group1',
      senderId: 'c3',
      senderName: 'Rohan Verma',
      text: 'Rohan: Let us do a group video call tonight at 8 PM!',
      timestamp: '11:15 AM',
      date: '2026-09-09',
      status: 'read',
      type: 'text',
      reactions: { '🔥': 3, '🙌': 2 },
    }
  ],
  'chat_c2': [
    {
      id: 'pm1',
      chatId: 'chat_c2',
      senderId: 'me',
      text: 'Hi Priya, sent over the updated slide deck.',
      timestamp: 'Yesterday',
      date: '2026-09-08',
      status: 'read',
      type: 'document',
      attachment: {
        fileName: 'Q3_Strategy_Deck.pdf',
        fileSize: '4.8 MB',
        fileType: 'pdf',
      }
    },
    {
      id: 'pm2',
      chatId: 'chat_c2',
      senderId: 'c2',
      senderName: 'Priya Patel',
      text: 'Got it, see you at the meeting!',
      timestamp: 'Yesterday',
      date: '2026-09-08',
      status: 'read',
      type: 'text',
    }
  ],
  'chat_comm_announcements': [
    {
      id: 'com1',
      chatId: 'chat_comm_announcements',
      senderId: 'admin',
      senderName: 'Hub Administrator',
      text: '📢 Welcome to Tech Innovators Hub! Only Community Admins can post in this announcement channel.',
      timestamp: 'Sep 5',
      date: '2026-09-05',
      status: 'read',
      type: 'text',
    },
    {
      id: 'com2',
      chatId: 'chat_comm_announcements',
      senderId: 'admin',
      senderName: 'Hub Administrator',
      text: 'Admin: New hackathon registration is open for next week! 🚀 Check the Sub-Groups for team formation.',
      timestamp: 'Yesterday',
      date: '2026-09-08',
      status: 'read',
      type: 'text',
    }
  ]
};

export const initialStatuses: UserStatus[] = [
  {
    id: 'status_me',
    contactId: 'me',
    contactName: 'My Status',
    contactAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    statuses: [
      {
        id: 's_me_1',
        type: 'text',
        content: 'Building cool web applications with AI Studio! 🚀💻',
        backgroundColor: '#075e54',
        textColor: '#ffffff',
        timestamp: 'Today, 8:40 AM',
        viewsCount: 14,
      }
    ],
    allSeen: false,
  },
  {
    id: 'status_c1',
    contactId: 'c1',
    contactName: 'Aarav Sharma',
    contactAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    statuses: [
      {
        id: 's_c1_1',
        type: 'image',
        content: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&auto=format&fit=crop&q=80',
        caption: 'Design sprint in progress at office! ☕',
        timestamp: '35 minutes ago',
      },
      {
        id: 's_c1_2',
        type: 'text',
        content: '"Simplicity is the soul of efficiency." - Austin Freeman ✨',
        backgroundColor: '#7c3aed',
        textColor: '#ffffff',
        timestamp: '20 minutes ago',
      }
    ],
    allSeen: false,
  },
  {
    id: 'status_c4',
    contactId: 'c4',
    contactName: 'Ananya Gupta',
    contactAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    statuses: [
      {
        id: 's_c4_1',
        type: 'image',
        content: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
        caption: 'Sunset peace 🌅🕊️',
        timestamp: 'Today, 7:15 AM',
      }
    ],
    allSeen: false,
  },
  {
    id: 'status_c2',
    contactId: 'c2',
    contactName: 'Priya Patel',
    contactAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    statuses: [
      {
        id: 's_c2_1',
        type: 'text',
        content: 'Finished 10km morning run! 🏃‍♀️💪 #FitnessGoals',
        backgroundColor: '#0284c7',
        textColor: '#ffffff',
        timestamp: 'Yesterday, 8:12 PM',
      }
    ],
    allSeen: true,
  }
];

export const initialCommunities: Community[] = [
  {
    id: 'comm_tech',
    name: 'Tech Innovators Hub',
    description: 'Community for engineers, creators, developers, and tech founders sharing ideas and events.',
    avatar: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=150&auto=format&fit=crop&q=80',
    announcementChatId: 'chat_comm_announcements',
    createdAt: 'August 2026',
    subGroups: [
      {
        id: 'sg1',
        name: 'AI & Machine Learning Developers',
        avatar: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80',
        memberCount: 248,
        lastActivity: '10 mins ago',
      },
      {
        id: 'sg2',
        name: 'Web3 & Cloud Infrastructure',
        avatar: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=150&auto=format&fit=crop&q=80',
        memberCount: 194,
        lastActivity: '1 hour ago',
      },
      {
        id: 'sg3',
        name: 'UI/UX & Product Design',
        avatar: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=150&auto=format&fit=crop&q=80',
        memberCount: 312,
        lastActivity: 'Yesterday',
      }
    ]
  },
  {
    id: 'comm_neighborhood',
    name: 'Greenwood Society Residents',
    description: 'Official society community for announcements, security alerts, and local events.',
    avatar: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=150&auto=format&fit=crop&q=80',
    announcementChatId: 'chat_comm_announcements',
    createdAt: 'January 2026',
    subGroups: [
      {
        id: 'sg_res1',
        name: 'Tower A & B Discussion',
        avatar: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=150&auto=format&fit=crop&q=80',
        memberCount: 140,
        lastActivity: '3 hours ago',
      },
      {
        id: 'sg_res2',
        name: 'Sports & Cultural Club',
        avatar: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=150&auto=format&fit=crop&q=80',
        memberCount: 88,
        lastActivity: 'Yesterday',
      }
    ]
  }
];

export const initialCallHistory: CallRecord[] = [
  {
    id: 'call_1',
    contactId: 'c1',
    contactName: 'Aarav Sharma',
    contactAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    type: 'video',
    direction: 'incoming',
    timestamp: 'Today, 11:20 AM',
    duration: '14 min 32 sec',
  },
  {
    id: 'call_2',
    contactId: 'c3',
    contactName: 'Rohan Verma',
    contactAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    type: 'voice',
    direction: 'outgoing',
    timestamp: 'Today, 10:05 AM',
    duration: '4 min 12 sec',
  },
  {
    id: 'call_3',
    contactId: 'c2',
    contactName: 'Priya Patel',
    contactAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
    type: 'voice',
    direction: 'missed',
    timestamp: 'Yesterday, 6:40 PM',
  },
  {
    id: 'call_4',
    contactId: 'c1',
    contactName: 'Weekend Trip Group',
    contactAvatar: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=150&auto=format&fit=crop&q=80',
    type: 'video',
    direction: 'outgoing',
    timestamp: 'Sep 7, 9:30 PM',
    duration: '38 min 10 sec',
    isGroup: true,
    groupParticipants: ['Aarav', 'Priya', 'Rohan', 'Ananya'],
  },
  {
    id: 'call_5',
    contactId: 'c4',
    contactName: 'Ananya Gupta',
    contactAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    type: 'voice',
    direction: 'incoming',
    timestamp: 'Sep 6, 2:15 PM',
    duration: '8 min 45 sec',
  }
];

export const initialDailyUsage: DailyUsage[] = [
  { date: '2026-09-03', dayName: 'Thu', totalMinutes: 84, messagesSent: 64, messagesReceived: 120, callMinutes: 22 },
  { date: '2026-09-04', dayName: 'Fri', totalMinutes: 112, messagesSent: 92, messagesReceived: 180, callMinutes: 35 },
  { date: '2026-09-05', dayName: 'Sat', totalMinutes: 145, messagesSent: 130, messagesReceived: 210, callMinutes: 52 },
  { date: '2026-09-06', dayName: 'Sun', totalMinutes: 160, messagesSent: 145, messagesReceived: 250, callMinutes: 64 },
  { date: '2026-09-07', dayName: 'Mon', totalMinutes: 95, messagesSent: 78, messagesReceived: 140, callMinutes: 18 },
  { date: '2026-09-08', dayName: 'Tue', totalMinutes: 125, messagesSent: 110, messagesReceived: 195, callMinutes: 42 },
  { date: '2026-09-09', dayName: 'Today', totalMinutes: 68, messagesSent: 42, messagesReceived: 88, callMinutes: 19 },
];
